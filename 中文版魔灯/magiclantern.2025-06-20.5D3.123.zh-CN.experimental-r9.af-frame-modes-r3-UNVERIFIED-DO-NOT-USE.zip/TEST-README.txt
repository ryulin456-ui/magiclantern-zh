5D3.123 AF-frame mode comparison r3 (TEST ONLY)

This archive is based on the user-tested r9 package. Its original core and
all original modules are retained. Added modules:

- af_live.mo: only runs when Canon Live AF or Face Live AF is selected.
- af_quick.mo: only runs when Canon Quick AF is selected.

Both modules watch the Canon LiveView AF frame. After it stops moving for
about 0.35 second, the matching module triggers one Canon-native autofocus.
They work only in Movie mode LiveView before recording begins.

TEST PROCEDURE
1. Enable only one of af_live or af_quick in the Modules tab and reboot.
2. Enter Movie mode LiveView; do not begin recording.
3. In Canon menu choose Live/Face Live AF for af_live, or Quick AF for
   af_quick. The wrong module will display a mode-mismatch warning.
4. In the Focus tab enable the matching experimental module.
5. Move the Canon AF frame onto a textured, well-lit subject and stop moving.
6. Observe one automatic focus operation. Do not enable both modules at once.

Quick AF is expected to be faster but temporarily interrupts LiveView during
focus. Live AF keeps the LiveView image but may be slower. Stop testing and
restart without the card if any abnormal behaviour occurs.
